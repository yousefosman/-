

var bookMarkNameInput = document.getElementById("name");
var bookMarkUrlInput = document.getElementById("url");
var bookMarkSubmit = document.getElementById("submit");


var allBookMark = [];

if (localStorage.getItem("BMarks") != null) {

    allBookMark = JSON.parse(localStorage.getItem("BMarks"));

    display();
}

function validName(){

    var regex = /^[A-Z][A-Za-z]{0,9}$/

    if (regex.test(bookMarkNameInput.value) == true) {

        document.getElementById("alertName").classList.replace("d-block", "d-none")


        return true

    }
    document.getElementById("alertName").classList.replace("d-none", "d-block")
    return flase

}

function validUrl() {

    var regex = /^https:\/\/www\..*\.com$/

    if (regex.test(bookMarkUrlInput.value) == true) {

        document.getElementById("alertUrl").classList.replace("d-block", "d-none")


        return true

    }
    document.getElementById("alertUrl").classList.replace("d-none", "d-block")
    return flase

}
function addBookMark() {

    if (validName() == true && validUrl() == true) {

        var bookMark = {
            name: bookMarkNameInput.value,
            url: bookMarkUrlInput.value,

        }

        allBookMark.push(bookMark)

        localStorage.setItem("BMarks", JSON.stringify(allBookMark))
        console.log(bookMark)
        clearData()
        display()
    }
}

function clearData() {

    bookMarkNameInput.value = ""
    bookMarkUrlInput.value = ""
}

function display() {
    var cartoona = ""
    for (i = 0; i < allBookMark.length; i++) {
        cartoona +=
            `
            <tr class="text-center text-capitalize">
                <td>${i + 1}</td>
                <td>${allBookMark[i].name}</td>
                <td><button class="btn btn-dark border-0"><i class=" text-white fa-solid fa-eye pe-2"></i><a class="text-decoration-none text-white" href=${allBookMark[i].url}>Visit</a></button></td>
                <td><button onclick="deleteProduct(${i})" class="btn btn-danger">Delete</button></td>
            </tr>
        `
    }
    document.getElementById("demo").innerHTML = cartoona;
}

function deleteProduct(index) {

    allBookMark.splice(index, 1);
    localStorage.setItem("BMarks", JSON.stringify(allBookMark))
    display();
}









